const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const mysql = require('mysql')
const port = 3000

function execSQLQuery(sqlQry, res) {
  const connection = mysql.createConnection({
    host: 'vhw3t8e71xdz9k14.cbetxkdyhwsb.us-east-1.rds.amazonaws.com',
    port: 3306,
    user: 'ecq7fu964vzkhtf3',
    password: 'woslq2rb62jqr5iw',
    database: 'jgj3xbxq8kakohwz',
  })

  connection.query(sqlQry, function(error, results, fields) {
    if (error) res.json(error)
    else res.json(results)
    connection.end()

    console.log('executou!')
  })
}

// configurando o body parser para pegar os post
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())

// definindo as rotas
const router = express.Router()

router.get('/', (req, res) => {
  res.json({ message: 'Hello word para ñ dar azar' })
})

//listar todos os usuario
router.get('/usuario/listar', (req, res) => {
  execSQLQuery('SELECT * FROM usuario', res)
})

// lista por id
router.get('/usuario/user/:id?', (req, res) => {
  let filter = ''
  if (req.params.id) filter = ' WHERE id=' + parseInt(req.params.id) // evitando sql injection
  console.log('o id passado foi ' + req.params.id)
  execSQLQuery('SELECT * FROM usuario ' + filter, res)
})

router.post('/usuario/adicionar/', (req, res) => {
  const nome = req.body.nome
  const email = req.body.email
  const senha = req.body.senha
  const dtNascimento = req.body.dtNascimento
  const cep = req.body.cep
  const estado = req.body.estado
  const bairro = req.body.bairro
  const rua = req.body.rua

  console.log(req.body)
  const query = `INSERT INTO usuario (nome, email, senha, dtNascimento, cep, bairro, rua, estado)
     VALUES ('${nome}', '${email}', '${senha}', '${dtNascimento}', '${cep}', '${bairro}', '${rua}', '${estado}')`
  console.log(query)

  execSQLQuery(query, res)
})

app.use('/', router)
app.listen(process.env.PORT || port)
console.log(`API funcionando`)
